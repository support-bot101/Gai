ai made simple
google search powerd ai
dose not store questions
is meant for info or defonition finding
